





<!DOCTYPE html>
<html lang="pt-BR" class="page-simple">
<head>
	<meta charset="UTF-8">
<meta name="version" content="2.9.45-03">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<head><link rel="apple-touch-icon" sizes="180x180" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/images/main-icons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/images/main-icons/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/images/main-icons/favicon-32x32.png">

<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/images/main-icons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#00adef">
<meta name="theme-color" content="#ffffff"></head>

	<title>Não foi possível acessar a página | 99Freelas</title>

	
		<meta name="robots" content="noindex">
	

	<!-- CSS -->
	


<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,700,800,300' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/main.css">
<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/modules/page-simple.css">
<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/modules/modal.css">
<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/modules/faq-box.css">




<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/modules/search-box.css">
<link rel="stylesheet" href="https://d1fuainj13qzhu.cloudfront.net/2.9.45/css/modules/search-popup.css">




	<!-- CSS Específico -->
	
		
	
</head>
<body>
	<div class="page-simple-wrapper">
		
			
				
					
					
						

<header class="header">
	<div class="header-inner">
		<div class="logo-container">
			<a href="/">
				<span class="logo"></span>
			</a>
		</div>

		<span class="link search-button-mobile btn-open-search-popup" href="#"><span class="icon-search-white"></span>Pesquisar</span>

		<div class="search-projetos-freelancers search-box">
			<form action="/search" method="get">
				<span class="dropdown">
					<span class="search-active">
						<span class="name">Freelancers</span>
						<span class="icon-arrow-bottom"></span>
					</span>
					<span class="search-hide" data-key="projetos">Projetos</span>
					<span class="search-hide" data-key="freelancers">Freelancers</span>
				</span>

				<input name="search-for" type="hidden" value="freelancers">
				<input type="search" placeholder="Buscar freelancers">

				<button type="submit"><span class="icon-search generic"></span></button>
			</form>
		</div>

		<div class="user-links">
			<a class="link link-clean hide-on-mobile show-on-mobile btn-open-search-popup" href="#">Pesquisar</a>
			<a class="link link-clean " href="/login">Login</a>
			<a class="link link-clean" href="/register">Cadastre-se</a>
			<a class="btn btn-medium btn-blue hide-on-mobile" href="/project/new">Publicar projeto</a>
		</div>
	</div>
</header>
					
				
			
			
		

		<div class="page-simple-content">
			
			
				
				<div class="content-box-message fail">A url do projeto é inválida. Por favor, verifique.</div>
			
		</div>

		
			
				

<footer class="footer footer-simples">
	<p>@2014-2025 99Freelas. Todos os direitos reservados.</p>
	<p class="footer-links">
		<a class="simple-link" href="/termos">Termos de uso</a>
		|
		<a class="simple-link" href="/privacidade">Política de privacidade</a>
	</p>
</footer>
			
			
		
	</div>

	<div class="container-include">
		



<div class="dark-background"></div>

<div class="fullscreen-loading-outer">
	<div class="fullscreen-loading fixed">
		<img src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/images/loading-circles.gif" alt="Carregando...">
		<p>Carregando...</p>
	</div>
</div>



<div class="search-projetos-freelancers search-popup">
	<div class="search-popup-inner">
		<span class="btn-close icon-close"></span>

		<h2>Pesquisar</h2>

		<div class="search-choice">
			<div class="search-choice-item" data-key="freelancers">FREELANCERS</div>
			<div class="search-choice-item" data-key="projetos">PROJETOS</div>
		</div>

		<form class="input-button-group" action="/search" method="get">
			<input type="hidden" name="search-for" value="freelancers">
			<input type="search" placeholder="Buscar freelancers">
			<button type="submit"><span class="icon-search generic"></span></button>
		</form>
	</div>
</div>

<div class="general-msg-box with-action box-cookie specific">
	<span class="close"></span>
    <div class="content infinite-time">
        Nós fazemos uso de cookies em nosso site para melhorar a sua experiência. Ao utilizar a 99Freelas, você aceita o uso de cookies de acordo com a nossa <a href="/privacidade">política de privacidade</a>.
    </div>
</div>

<div class="general-msg-box success specific">
	<span class="close"></span>
	
</div>

<div class="general-msg-box error specific">
	<span class="close"></span>
	
</div>

<div class="general-msg-box error default">
	<span class="close"></span>
	<div class="content infinite-time">

		<span class="default-msg">
			Ocorreu um erro inesperado. Caso o erro persista, entre em contato conosco através do e-mail <a href="mailto:suporte@99freelas.com.br">suporte@99freelas.com.br</a>.
		</span>
	</div>
</div>



<div class="preferencias-info-container">
	
</div>

	</div>

	<div class="container-bottom">
		
			


<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/main.js"></script>















<script nonce="PDclr1CxZEzY06eIo70tNg==">
	(function(){
		var VERSION                = '2.9.45',
			RESOURCES_FULL_CONTEXT = 'https://d1fuainj13qzhu.cloudfront.net',
			RESOURCES_BASE_PATH    = RESOURCES_FULL_CONTEXT + '/' + VERSION,
			PREMIUM                = ('' == 'true'),
			BUSINESS_PLAN          = ('' == 'true'),

			INTEREST_AREAS_FREE = parseInt('5'),
			INTEREST_AREAS_PRO = parseInt('20'),
			INTEREST_AREAS_BUSINESS = parseInt('30'),
			ABILITIES_FREE = parseInt('10'),
			ABILITIES_PRO = parseInt('30'),
			ABILITIES_BUSINESS = parseInt('50'),
			PORTFOLIO_JOBS_FREE = parseInt('3'),
			PORTFOLIO_JOBS_PRO = parseInt('12'),
			PORTFOLIO_JOBS_BUSINESS = parseInt('15'),
			CLIENTS_TO_FOLLOW_FREE = parseInt('0'),
			CLIENTS_TO_FOLLOW_PRO = parseInt('3'),
			CLIENTS_TO_FOLLOW_BUSINESS = parseInt('10'),
			MONTLY_PROMOTED_BIDS_FREE = parseInt('0'),
			MONTLY_PROMOTED_BIDS_PRO = parseInt('2'),
			MONTLY_PROMOTED_BIDS_BUSINESS = parseInt('5'),

			BID_TAX_FREE = parseFloat('20'),
			BID_TAX_PRO = parseFloat('15'),
			BID_TAX_BUSINESS = parseFloat('10'),
			BID_MIN_TAX_VALUE_FREE = parseFloat('5'),
			BID_MIN_TAX_VALUE_PRO = parseFloat('5'),
			BID_MIN_TAX_VALUE_BUSINESS = parseFloat('5'),

			MAX_AREAS_INTERESSE      = BUSINESS_PLAN ? INTEREST_AREAS_BUSINESS :
				(PREMIUM ? INTEREST_AREAS_PRO : INTEREST_AREAS_FREE),
			MAX_HABILIDADES          = BUSINESS_PLAN ? ABILITIES_BUSINESS :
				(PREMIUM ? ABILITIES_PRO : ABILITIES_FREE),
			MAX_PORTFOLIO_JOBS       = BUSINESS_PLAN ? PORTFOLIO_JOBS_BUSINESS :
				(PREMIUM ? PORTFOLIO_JOBS_PRO : PORTFOLIO_JOBS_FREE),
			MAX_CLIENTS_TO_FOLLOW    = BUSINESS_PLAN ? CLIENTS_TO_FOLLOW_BUSINESS :
				(PREMIUM ? CLIENTS_TO_FOLLOW_PRO : CLIENTS_TO_FOLLOW_FREE),
			MAX_MONTLY_PROMOTED_BIDS = BUSINESS_PLAN ? MONTLY_PROMOTED_BIDS_BUSINESS :
				(PREMIUM ? MONTLY_PROMOTED_BIDS_PRO : MONTLY_PROMOTED_BIDS_FREE),
			USER_BID_TAX             = BUSINESS_PLAN ? BID_TAX_BUSINESS :
				(PREMIUM ? BID_TAX_PRO : BID_TAX_FREE),
			USER_BID_MIN_TAX_VALUE   = BUSINESS_PLAN ? BID_MIN_TAX_VALUE_BUSINESS :
				(PREMIUM ? BID_MIN_TAX_VALUE_PRO : BID_MIN_TAX_VALUE_FREE)
		;

		NineNineFreelas.constants.General.VERSION    = VERSION;
		NineNineFreelas.constants.General.DEV_SERVER = ('false' == 'true');

		NineNineFreelas.constants.General.MAX_FILE_SIZE_MB = parseInt('16');

		NineNineFreelas.constants.Usuario.LOGADO       = ('false' == 'true');
		NineNineFreelas.constants.Usuario.ID_PESSOA    = '';
		NineNineFreelas.constants.Usuario.TIPO_USUARIO = parseInt('');
		NineNineFreelas.constants.Usuario.EMAIL        = '';

		NineNineFreelas.constants.Usuario.PREMIUM                  = PREMIUM;
		NineNineFreelas.constants.Usuario.BUSINESS_PLAN            = BUSINESS_PLAN;
		NineNineFreelas.constants.Usuario.MAX_AREAS_INTERESSE      = MAX_AREAS_INTERESSE;
		NineNineFreelas.constants.Usuario.MAX_HABILIDADES          = MAX_HABILIDADES;
		NineNineFreelas.constants.Usuario.MAX_PORTFOLIO_JOBS       = MAX_PORTFOLIO_JOBS;
		NineNineFreelas.constants.Usuario.MAX_CLIENTS_TO_FOLLOW    = MAX_CLIENTS_TO_FOLLOW;
		NineNineFreelas.constants.Usuario.MAX_MONTLY_PROMOTED_BIDS = MAX_MONTLY_PROMOTED_BIDS;
		NineNineFreelas.constants.Usuario.USER_BID_TAX             = USER_BID_TAX;
		NineNineFreelas.constants.Usuario.USER_BID_MIN_TAX_VALUE   = USER_BID_MIN_TAX_VALUE;

		NineNineFreelas.constants.General.JOIN_PROJECT_VALUES            = ('false'            == 'true');
		NineNineFreelas.constants.General.BID_VALUE_TAX_MIN              = ('false'              == 'true');
		NineNineFreelas.constants.General.DISABLE_PROJECTS_MINIMUM_VALUE = ('false' == 'true');
		NineNineFreelas.constants.General.PROFILE_IMAGE_SHOW_DEFAULT     = ('false'     == 'true');

		NineNineFreelas.constants.General.DISABLE_FORMATTED_TEXTS          = ('false' == 'true');
		NineNineFreelas.constants.General.DISABLE_USER_ACTION_CONFIRMATION = ('true' == 'true');

		

		

		NineNineFreelas.constants.Codigos.FACEBOOK_APP_ID         = '374289285940862';
		NineNineFreelas.constants.Codigos.ACCOUNT_KIT_API_VERSION = 'v1.1';
		NineNineFreelas.constants.Codigos.LINKEDIN_APP_ID         = '776c8bug26pxwm';
		NineNineFreelas.constants.Codigos.GOOGLE_APP_ID           = '802835387828-p3jp82l8esaqkhbsmfbdo644uc7306st';
		NineNineFreelas.constants.Codigos.GOOGLE_CLIENT_API_KEY   = 'AIzaSyBq7cmzWOdQyAX4d1YuMJRctYZq0v7Dh3E';

		NineNineFreelas.constants.Codigos.USE_ACCOUNT_KIT                = ('false' === 'true');
		NineNineFreelas.constants.Codigos.USAR_CAPTCHA_REGISTER          = ('true' === 'true');
		NineNineFreelas.constants.Codigos.USAR_CAPTCHA_REDEFINE_PASSWORD = ('true' === 'true');
		NineNineFreelas.constants.Codigos.USAR_CAPTCHA_LOGIN             = ('true' === 'true');
		NineNineFreelas.constants.Codigos.USAR_RECAPTCHA_V2              = ('true' === 'true');
		NineNineFreelas.constants.Codigos.RECAPTCHA_V2_SITE_KEY          = '6LfH7p0UAAAAAO9YWzDl15jVHA9NHfScvWU5iTRO';
		NineNineFreelas.constants.Codigos.USAR_RECAPTCHA_V3              = 'false' === 'true';
		NineNineFreelas.constants.Codigos.RECAPTCHA_V3_SITE_KEY          = '6LfZGmAUAAAAANDRc2Zk9rShOtaZgk-QHilauuSr';

		NineNineFreelas.constants.Codigos.STRIPE_PUBLISHABLE_KEY          = 'pk_live_7ahQoOM4JZuemxQQgynhkuiH00OFYF64fa';

		NineNineFreelas.constants.Urls.contexto                           = 'https://www.99freelas.com.br/';
		NineNineFreelas.constants.Urls.AMAZON_S3_BUCKET_URL               = 'https://99freelas.s3-sa-east-1.amazonaws.com';
		NineNineFreelas.constants.Urls.FILE_S3_BASE_URL                   = 'https://d2tfco5ldvlr4r.cloudfront.net';
		NineNineFreelas.constants.Urls.RESOURCES_FULL_CONTEXT             = RESOURCES_FULL_CONTEXT;
		NineNineFreelas.constants.Urls.RESOURCES_BASE_PATH                = RESOURCES_BASE_PATH;
		NineNineFreelas.constants.Urls.MOIP_V1_JAVASCRIPT_URL             = 'https://www.moip.com.br/transparente/MoipWidget-v2.js';
		NineNineFreelas.constants.Urls.CONTEXT_NOTIFICATION_CLIENT        = 'https://ws.99freelas.com.br:3000';
		NineNineFreelas.constants.Urls['registerClient' + 'facebook']     = 'https://www.facebook.com/dialog/oauth?client_id=374289285940862&scope=email&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Fclient%2Ffacebook';
		NineNineFreelas.constants.Urls['registerFreelancer' + 'facebook'] = 'https://www.facebook.com/dialog/oauth?client_id=374289285940862&scope=email&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Ffreelancer%2Ffacebook';
		NineNineFreelas.constants.Urls['registerClient' + 'linkedin']     = 'https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=776c8bug26pxwm&state=DCEeFWf46A53sdfKef424&scope=r_liteprofile%20r_emailaddress&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Fclient%2Flinkedin';
		NineNineFreelas.constants.Urls['registerFreelancer' + 'linkedin'] = 'https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=776c8bug26pxwm&state=DCEeFWf46A53sdfKef424&scope=r_liteprofile%20r_emailaddress&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Ffreelancer%2Flinkedin';
		NineNineFreelas.constants.Urls['registerClient' + 'google']     = 'https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=802835387828-p3jp82l8esaqkhbsmfbdo644uc7306st&state=DCEeFWf46A53sdfKef424&scope=profile%20email%20openid&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Fclient%2Fgoogle';
		NineNineFreelas.constants.Urls['registerFreelancer' + 'google'] = 'https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=802835387828-p3jp82l8esaqkhbsmfbdo644uc7306st&state=DCEeFWf46A53sdfKef424&scope=profile%20email%20openid&redirect_uri=https%3A%2F%2Fwww.99freelas.com.br%2Fregister%2Ffreelancer%2Fgoogle';
	})();
</script>









<script nonce="PDclr1CxZEzY06eIo70tNg==">
	(function() {
		

		

		

		

		

		

		

		

		

		

		

		

		
	})();
</script>







<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery-1.8.2.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.form.min.js"></script>


	
	
		<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery-ui-draggable.min.js"></script>
		<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery-ui-1.11.4.custom.effects.min.js"></script>
	


<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.shorten.1.0.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.mCustomScrollbar.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.mousewheel.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.cp-plugins.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.expander.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/linkify.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/linkify-jquery.min.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/EventEmitter.js"></script>

<script nonce="PDclr1CxZEzY06eIo70tNg==">
	$(document).ready(function() {
		if (linkify && linkify.options) {
			linkify.options.defaults.attributes = {
				rel: 'nofollow'
			};

			linkify.options.defaults.target = {
				url: '_blank'
			};
		}
	});
</script>

<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/ServiceUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/ValidationUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/MessageUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/UrlUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/TooltipUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/StringUtils.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/utils/DateUtils.js"></script>

<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/Events.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/Error.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/InputCount.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/ConcurrencyMod.js"></script>

<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/FaqBox.js"></script>




	<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/Modal.js"></script>
	<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/SimpleModal.js"></script>



	


<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/SearchBox.js"></script>
<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/modules/SearchPopUp.js"></script>


	
	
		<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/pages/templates/header.js"></script>
	



<script nonce="PDclr1CxZEzY06eIo70tNg==">
	$(document).ready(function() {
		var MessageUtils = NineNineFreelas.prepare(NineNineFreelas.utils.MessageUtils);
		MessageUtils.verifyMessage();

        // Aviso de Cookies
        var itemName = 'use_cookies';
        var valueToUse = 'true';
        var cookieAcceptedStr = localStorage && localStorage.getItem('use_cookies');
        var cookieAccepted = (cookieAcceptedStr || '') === valueToUse;

        if (!cookieAccepted) {
            MessageUtils.exibirMsgWithAction('box-cookie', function() { localStorage.setItem('use_cookies', valueToUse); });
        }

		var UrlUtils = NineNineFreelas.prepare(NineNineFreelas.utils.UrlUtils);
		UrlUtils.fixUrl();
		UrlUtils.handleImagesWithPlaceholder('.nnf-with-placeholder');

		var StringUtils = NineNineFreelas.prepare(NineNineFreelas.utils.StringUtils);
		StringUtils.formatElementsText($('.nnf-document'));
	});
</script>


			<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.raty.min.js"></script>
			<script src="https://d1fuainj13qzhu.cloudfront.net/2.9.45/js/plugins/jquery.qtip.min.js"></script>

			
		

		






	
	
		<script async nonce="PDclr1CxZEzY06eIo70tNg==" src="https://www.googletagmanager.com/gtag/js?id=G-FFBBM281KW"></script>

		<script nonce="PDclr1CxZEzY06eIo70tNg==">
			window.dataLayer = window.dataLayer || [];

			function gtag(){dataLayer.push(arguments);}

			gtag('js', new Date());
		</script>

		

		
			<script nonce="PDclr1CxZEzY06eIo70tNg==">
				gtag('config', 'G-FFBBM281KW', {
					'cookie_domain': 'none',
				});
			</script>
		
	





	

<script nonce="PDclr1CxZEzY06eIo70tNg==">(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '321450218005538']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img class="force-hide" height="1" width="1" alt="" src="https://www.facebook.com/tr?id=321450218005538&amp;ev=PixelInitialized" /></noscript>









	</div>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" nonce="PDclr1CxZEzY06eIo70tNg==" data-cf-beacon='{"version":"2024.11.0","token":"cfa12a17274b4e1d9ac72e32c6a4af82","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
